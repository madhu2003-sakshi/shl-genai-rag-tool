import os
import faiss
import pickle
import numpy as np
from openai.embeddings_utils import get_embedding
from catalog_loader import load_pdf_chunks

EMBEDDING_MODEL = "text-embedding-ada-002"
INDEX_FILE = "faiss_index.idx"
CHUNKS_FILE = "chunks.pkl"

def create_faiss_index(chunks):
    embeddings = [get_embedding(chunk, engine=EMBEDDING_MODEL) for chunk in chunks]
    dim = len(embeddings[0])
    index = faiss.IndexFlatL2(dim)
    index.add(np.array(embeddings).astype("float32"))

    with open(CHUNKS_FILE, "wb") as f:
        pickle.dump(chunks, f)
    faiss.write_index(index, INDEX_FILE)

def load_index():
    index = faiss.read_index(INDEX_FILE)
    with open(CHUNKS_FILE, "rb") as f:
        chunks = pickle.load(f)
    return index, chunks
