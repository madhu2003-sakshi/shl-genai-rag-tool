import streamlit as st
from rag_pipeline import get_response

st.title("SHL Product Catalog Q&A")
query = st.text_input("Ask a question about SHL products:")

if query:
    with st.spinner("Thinking..."):
        answer = get_response(query)
        st.markdown("### Answer:")
        st.write(answer)
