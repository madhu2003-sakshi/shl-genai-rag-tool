import numpy as np
import openai
from openai.embeddings_utils import get_embedding, cosine_similarity
from vector_store import load_index

EMBEDDING_MODEL = "text-embedding-ada-002"
LLM_MODEL = "gpt-3.5-turbo"

index, chunks = load_index()

def get_top_chunk(query):
    query_embedding = get_embedding(query, engine=EMBEDDING_MODEL)
    scores = [cosine_similarity(query_embedding, get_embedding(chunk, engine=EMBEDDING_MODEL)) for chunk in chunks]
    top_idx = np.argmax(scores)
    return chunks[top_idx]

def get_response(query):
    top_chunk = get_top_chunk(query)
    prompt = f"Use the following context to answer the question.\n\nContext: {top_chunk}\n\nQuestion: {query}\n\nAnswer:"
    response = openai.ChatCompletion.create(
        model=LLM_MODEL,
        messages=[{"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content'].strip()
